# bower-jvectormap

A built version of [jVectorMap][] (MIT license), suitable for consumption by
bower.

Includes the following maps:

* [Whole World][1] (Miller variant, license: [public domain][2])

  [jvectormap]: http://jvectormap.com/
  [1]: http://jvectormap.com/maps/world/world/
  [2]: http://www.naturalearthdata.com/about/terms-of-use/
