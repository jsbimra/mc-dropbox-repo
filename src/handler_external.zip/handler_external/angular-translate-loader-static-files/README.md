# bower-angular-translate-loader-static-files

angular-translate-loader-static-files bower package

### Installation

````
$ bower install angular-translate-loader-static-files
````
